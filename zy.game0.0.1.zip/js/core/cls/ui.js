﻿/**********************************************************
面界(UI)类
**********************************************************/

var ui={
	form   : new clsForm(),
	label  : new clsLabel(),
	text   : new clsText(),
	radio  : new clsRadio(),
	bar    : new clsBar(),
	scroll : new clsScroll(),
	select : new clsSelect(),
	image  : new clsImage(),
	button : new clsButton()
};
